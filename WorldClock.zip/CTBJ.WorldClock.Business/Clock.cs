﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CTBJ.WorldClock.Business
{
    public class Clock
    {
        private DateTime UTCTime;
        private DateTime BeijingTime;
        private DateTime LondonTime;
        private DateTime MoscowTime;
        private DateTime SydneyTime;
        private DateTime NewYorkTime;

        public void setUTCTime(DateTime utcTime)
        {
            this.UTCTime = utcTime;

            this.notifyAllCity();
        }

        private void notifyAllCity()
        {
            this.BeijingTime = UTCTime.AddHours(8);
            this.LondonTime = new DST().adjust("London", UTCTime);
            this.MoscowTime = UTCTime.AddHours(4);
            this.SydneyTime = UTCTime.AddHours(10);
            this.NewYorkTime = new DST().adjust("NewYork", UTCTime.AddHours(-5));
        }

        public List<DateTime> getAllCityTime()
        {
            List<DateTime> times = new List<DateTime>();
            times.Add(this.BeijingTime);
            times.Add(this.LondonTime);
            times.Add(this.MoscowTime);
            times.Add(this.SydneyTime);
            times.Add(this.NewYorkTime);

            return times;
        }
    }
}
