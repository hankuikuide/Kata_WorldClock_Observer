﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CTBJ.WorldClock.Business
{
    class DST
    {
        private DateTime begin;

        private DateTime end;
      
        public DST()
        {           
        }

        public DateTime adjust(string city, DateTime UTCTime)
        {
            DateTime time;
            switch (city)
            {
                case "London":
                    this.begin = DateTime.Parse(UTCTime.Year + "-3-31");
                    this.end = DateTime.Parse(UTCTime.Year + "-10-27");
                    time = this.getDSTTime(UTCTime);
                    break;
                case "NewYork":
                    this.begin = DateTime.Parse(UTCTime.Year + "-3-10");
                    this.end = DateTime.Parse(UTCTime.Year + "-11-3");
                    time = this.getDSTTime(UTCTime);
                    break;
                default:
                    time = UTCTime;
                    break;
            }

            return time;
        }

        private DateTime getDSTTime(DateTime UTCTime)
        {
            if (UTCTime >= this.begin && UTCTime <= this.end)
            {
                 UTCTime =UTCTime.AddHours(1);
            }

            return UTCTime;
        }
    }
}
