﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CTBJ.WorldClock.Business;

namespace CTBJ.WorldClock.Test
{
    [TestClass]
    public class ClockTest
    {
        [TestMethod]
        public void ShowTimeTest()
        {
            List<DateTime> expected = new List<DateTime>();
            expected.Add(DateTime.Parse("2013-9-2 8:00:00"));
            expected.Add(DateTime.Parse("2013-9-2 1:00:00"));
            expected.Add(DateTime.Parse("2013-9-2 4:00:00"));
            expected.Add(DateTime.Parse("2013-9-2 10:00:00"));
            expected.Add(DateTime.Parse("2013-9-1 20:00:00"));

            DateTime UTCTime = DateTime.Parse("2013-9-2 0:00:00");

            Clock clock = new Clock();
            clock.setUTCTime(UTCTime);
            List<DateTime> times=clock.getAllCityTime();

            for (int i = 0; i < times.Count; i++)
            {
                Assert.AreEqual(expected[i],times[i]);
            }


        }
    }
}
